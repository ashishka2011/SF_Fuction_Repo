import { LightningElement, api } from "lwc";

export default class FunctionsRecipesPageHeader extends LightningElement {
  @api title;
  @api subTitle;
}
