import { LightningElement } from "lwc";

export default class FunctionInvocationContainer extends LightningElement {}
