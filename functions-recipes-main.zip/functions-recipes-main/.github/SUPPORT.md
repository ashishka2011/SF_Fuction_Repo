**Looking for help?**

Check out the documentation:

- [Lightning Web Components documentation](https://developer.salesforce.com/docs/component-library/documentation/lwc)
- [Salesforce Functions documentation](https://developer.salesforce.com/docs/platform/functions/guide/index.html)
